import{bu as r}from"./index-f42e34d4.js";function n(n){return r({url:"/login",data:n})}function o(){return r({url:"/logout"})}export{o as a,n as l};
