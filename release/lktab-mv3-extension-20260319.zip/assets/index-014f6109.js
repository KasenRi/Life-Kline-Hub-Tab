import{bu as o}from"./index-c4713bae.js";function u(r){return o({url:"/login",data:r})}function n(){return o({url:"/logout"})}export{n as a,u as l};
