import{bu as o}from"./index-48ca1da2.js";function u(r){return o({url:"/login",data:r})}function n(){return o({url:"/logout"})}export{n as a,u as l};
