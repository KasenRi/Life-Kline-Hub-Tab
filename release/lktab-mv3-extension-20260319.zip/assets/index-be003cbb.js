import{bu as o}from"./index-9ee7c9bf.js";function u(r){return o({url:"/login",data:r})}function n(){return o({url:"/logout"})}export{n as a,u as l};
