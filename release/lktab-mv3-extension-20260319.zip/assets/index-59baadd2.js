import{bu as r}from"./index-56d91760.js";function n(n){return r({url:"/login",data:n})}function o(){return r({url:"/logout"})}export{o as a,n as l};
